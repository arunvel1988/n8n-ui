# AI DevOps Docker Lab (Docker Compose only)

This lab runs Flask, Prometheus, Grafana, n8n, Ollama, and a read-only Docker investigation MCP server. No Kubernetes cluster is required.

## Requirements
- Ubuntu/Linux host with Docker Engine and Docker Compose plugin
- At least 16 GB RAM recommended if running `qwen3:8b`; smaller Ollama models can be used on smaller machines
- Docker socket access for the MCP server (highly privileged; isolated lab only)

## Start
```bash
# Change the n8n encryption key in docker-compose.yml before use.
docker compose up -d --build
docker compose ps

# Download the model
docker exec -it ollama ollama pull qwen3:8b
docker exec ollama ollama list
```

## URLs
- n8n: http://localhost:5678
- Grafana: http://localhost:3000 (admin / admin123)
- Prometheus: http://localhost:9090
- Flask: http://localhost:5000
- Ollama API: http://localhost:11434
- Docker MCP Streamable HTTP: http://localhost:8080/mcp

For a remote VM, replace `localhost` with the VM address in your browser. Configure n8n's `N8N_HOST`, `WEBHOOK_URL`, and `N8N_EDITOR_BASE_URL` accordingly. Restrict firewall access; do not expose n8n, Docker MCP, or Ollama publicly.

## n8n workflow outline
Create:
1. Webhook node: POST path `docker-incident`
2. AI Agent node
3. Ollama Chat Model connected to AI Agent's Chat Model input
4. MCP Client Tool connected to AI Agent's Tools input
5. Slack node connected after the AI Agent

Ollama Chat Model:
- Base URL: `http://ollama:11434`
- Model: `qwen3:8b` (or a model actually pulled into Ollama)

MCP Client Tool:
- Transport: Streamable HTTP
- URL: `http://docker-mcp:8080/mcp`

Available MCP tools:
- `list_containers`
- `inspect_container`
- `get_container_logs`

AI Agent system instructions:
```text
You are a read-only Docker incident investigation agent.
For each alert, identify the affected container, call list_containers,
inspect_container and get_container_logs as needed. Report observed
container status, restart count, relevant log evidence, likely root cause,
recommended remediation and confidence. Never invent evidence. Never
stop, restart, remove, exec into, or modify containers.
```

For the AI Agent user prompt, adapt to your incoming webhook schema, for example:
```text
Investigate this Docker incident:
{{ JSON.stringify($json.body ?? $json) }}
Use Docker MCP tools to inspect the named container and report findings.
```

## Test the application
```bash
curl http://localhost:5000/
curl -X POST http://localhost:5678/webhook-test/docker-incident \
  -H 'Content-Type: application/json' \
  -d '{"body":{"alertname":"DockerContainerRestarting","container":"demo-app","severity":"critical"}}'
```
Use `/webhook-test/` while the n8n workflow is in test/listening mode. Once activated, use `/webhook/`.

To intentionally crash the demo app:
```bash
curl http://localhost:5000/crash
docker ps -a
docker inspect demo-app --format='Status={{.State.Status}} RestartCount={{.RestartCount}}'
docker logs --tail 100 demo-app
```
The app has `restart: unless-stopped`, so Docker will restart it after `/crash`.

## Grafana and Prometheus
Prometheus scrapes `app:5000/metrics`. Add Prometheus as a Grafana data source:
`http://prometheus:9090`.

The included Compose file does not provision Grafana alert rules or a Slack contact point. Configure a Grafana-managed alert rule and webhook contact point in the Grafana UI, pointing to the n8n webhook. For a quick workflow test, send a test webhook directly.

## Security notes
- Mounting `/var/run/docker.sock` grants powerful control over the Docker host to whoever compromises the MCP container. The MCP tools in this sample are read-only by design, but the socket itself is not read-only in the security sense.
- Run only on an isolated lab VM. Do not expose port 8080 or the Docker socket publicly.
- Use a long random n8n encryption key and secure credentials.
- Restrict inbound ports with your host/cloud firewall.
- Do not use this demo as a production security boundary.
