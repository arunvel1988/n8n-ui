from flask import Flask, jsonify, Response
from prometheus_client import Counter, generate_latest, CONTENT_TYPE_LATEST
import logging
import os
import time

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
requests_total = Counter("app_requests_total", "Total application requests")

@app.route("/")
def home():
    requests_total.inc()
    app.logger.info("Home endpoint called")
    return jsonify(status="running")

@app.route("/health")
def health():
    requests_total.inc()
    return jsonify(status="healthy")

@app.route("/metrics")
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)

@app.route("/crash")
def crash():
    app.logger.error("Simulated application failure")
    os._exit(1)

@app.route("/slow")
def slow():
    requests_total.inc()
    app.logger.warning("Slow request received")
    time.sleep(10)
    return jsonify(status="completed")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
