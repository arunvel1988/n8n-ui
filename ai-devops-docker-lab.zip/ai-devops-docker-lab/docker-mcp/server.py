from mcp.server.fastmcp import FastMCP
import docker
import uvicorn

mcp = FastMCP("docker-investigation-tools")
client = docker.from_env()

@mcp.tool()
def list_containers() -> str:
    """List Docker containers and their status."""
    result = []
    for container in client.containers.list(all=True):
        result.append({
            "name": container.name,
            "id": container.short_id,
            "image": container.image.tags,
            "status": container.status
        })
    return str(result)

@mcp.tool()
def inspect_container(container_name: str) -> str:
    """Inspect a container's state and restart count."""
    container = client.containers.get(container_name)
    container.reload()
    state = container.attrs["State"]
    return str({
        "name": container.name,
        "status": container.status,
        "image": container.image.tags,
        "state": state,
        "restart_count": container.attrs["RestartCount"],
        "started_at": state.get("StartedAt"),
        "finished_at": state.get("FinishedAt"),
        "exit_code": state.get("ExitCode"),
        "error": state.get("Error")
    })

@mcp.tool()
def get_container_logs(container_name: str, tail_lines: int = 100) -> str:
    """Retrieve recent Docker container logs (maximum 300 lines)."""
    tail_lines = max(1, min(int(tail_lines), 300))
    container = client.containers.get(container_name)
    logs = container.logs(tail=tail_lines, timestamps=True)
    return logs.decode("utf-8", errors="replace")

if __name__ == "__main__":
    app = mcp.streamable_http_app()
    uvicorn.run(app, host="0.0.0.0", port=8080)
